<?php
  $materia = $_POST['materia'];
  $sql = "INSERT INTO mst_test VALUES ()";

 ?>
